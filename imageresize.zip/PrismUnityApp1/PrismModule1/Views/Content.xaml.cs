﻿using System.Windows.Controls;

namespace PrismModule1.Views
{
    /// <summary>
    /// Interaction logic for Content
    /// </summary>
    public partial class Content : UserControl
    {
        public Content()
        {
            InitializeComponent();
        }
    }
}
